# -*- coding: utf-8 -*-
import os
from pyepw.epw import EPW
from windrose import WindroseAxes
from windrose import WindAxes
from matplotlib import pyplot as plt
import matplotlib.cm as cm
import numpy as np

#############################
## Utilisation de la librairie EPW
print("Recupération données vent ...")
epw = EPW()
dossier_epw=r"./"

# recup automatique du EPW
fichier_epw = dossier_epw +"ENS_PS-hour.epw"

#lecture du fichier
epw.read(fichier_epw)
weather=epw.weatherdata

#############################
## Utilisation de Pandas
## On pourrait aussi "juste" lire le fichier epw comme un csv avec pandas,
# Mais il faut connaitre la structure des epw... 
import pandas as pd
data = pd.read_csv(fichier_epw, , sep=",", skiprows=8,header=None)
# L'ordre des colonnes dans le fichier EPW
columns=['Year','Month','Day','Hour','Minute','Data Source and Uncertaintly Flags',
    'Dry Bulb Temperature','Dew Point Temperature','Relative Humidity',
    'Atmospheric Station Pressure','Extraterrestrial Horizontal Radiation',
    'Extraterrestrial Direct Normal Radiation', 'Horizontal Infrared Radiation Intensity',
    'Global Horizontal Radiation', 'Direct Normal Radiation',
    'Diffuse Horizontal Radiation', 'Global Horizontal Illuminance',
    'Direct Normal Illuminance', 'Diffuse Horizontal Illuminance','Zenith Luminance',
    'Wind Direction', 'Wind Speed', 'Total Sky Cover', 'Opaque Sky Cover',
    'Visibility',	'Ceiling Height',	'Present Weather Observation',
    'Present Weather Codes', 'Precipitable Water', 'Aerosol Optical Depth',
    'Snow Depth', 'Days Since Last Snowfall', 'Albedo',
    'Liquid Precipitation Depth', 'Liquid Precipitation Quantity']
data_meteo.columns=columns


# stockage de ce qui nous intéresse
velocity=[data.wind_speed for data in weather]
angle=[data.wind_direction for data in weather]
# OU
#velocity = data_meteo['Wind Speed'].to_list()
#angle = data_meteo['Wind Direction'].to_list()

a=[]
for i, theta  in enumerate(angle):
	if theta>75 and theta<105:
		a.append(velocity[i])

moyenne = np.mean(a)

#############################
# Essayer de sortir toutes les statistiques par direction de vent
# Partir sur 12 directions de vents [0,30,60,90,120,150,180,210,240,270,300,330]


#############################
# Solutions "out of the box", mais pas parfaite... 
# Construction Rose des vents
# 
ax = WindroseAxes.from_ax()
ax.bar(angle, velocity, normed=True, opening=0.9,nsector=12,bins=np.arange(0,8,1), edgecolor='k',cmap=cm.GnBu)
# ax.contourf(angle, air_vel, bins=np.arange(0, 8,1),nsectors=12, cmap=cm.hot)
ax.set_legend()
ax.set_xticklabels(['E', 'N-E', 'N', 'N-O', 'O', 'S-O', 'S', 'S-E'])
